package com.example.upper.joyevent;

/**
 * Created by upper on 18-9-1.
 */

import android.accessibilityservice.AccessibilityService;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Instrumentation;
import android.content.ComponentName;
import android.content.ContextWrapper;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
//import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.hardware.input.InputManager;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.InputDevice;
import android.view.SurfaceView;

import android.content.Context;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.MotionEvent.PointerCoords;
import android.view.MotionEvent.PointerProperties;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import static java.lang.Math.abs;

public class GameSurfaceView extends SurfaceView implements Callback,Runnable {
    private final static String TAG = "GameSurfaceView";
    private SurfaceHolder mHolder; // 用于控制SurfaceView
    private Context mContext;
    private String mPackageName;

    private Thread t; // 声明一条线程
    private boolean isRunning; // 线程运行的标识，用于控制线程
    private Canvas mCanvas; // 声明一张画布
    private Paint p; // 声明一支画笔
    private int circleX = 0xffff, circleY = 0xffff, circleR = 10; // 圆的坐标和半径
    private int dpadKeyCode = 0xffff;
    private boolean bSelfTestMode = false;

    private Dpad mDpad = new Dpad();
    private GameLayout game = null;
    private static int flagJoystickL = 0;//1:down 2:move 3:up 0:inactive
    private static int flagJoystickR = 0;//1:down 2:move 3:up 0:inactive
    private int originalX_L = 317;
    private int originalY_L = 811;
    private int originalX_R = 1489;
    private int originalY_R = 341;
    private int response_L = 10;
    private int response_R = 10;
    private String type_L;
    private String type_R;
    private int radius_L;//左摇杆半径
    private int radius_R;//右摇杆半径
    public final static int START_X = 306;
    public final static int START_Y = 815;
    public final static int DELTA = 100;
    public final static int MSG_ACTION_DOWN = 0x001;
    public final static int MSG_ACTION_UP = 0x002;
    public final static int MSG_ACTION_MOVE = 0x003;
    public final static int MSG_ACTION_DOWN_JOYSTICKL = 0x011;
    public final static int MSG_ACTION_UP_JOYSTICKL = 0x012;
    public final static int MSG_ACTION_MOVE_JOYSTICKL = 0x013;
    public final static int MSG_ACTION_DOWN_JOYSTICKR = 0x021;
    public final static int MSG_ACTION_UP_JOYSTICKR = 0x022;
    public final static int MSG_ACTION_MOVE_JOYSTICKR = 0x023;

    //两个摇杆同时控制
    public final static int MSG_ACTION_DOWN_JOYSTICK2_1 = 0x031;
    public final static int MSG_ACTION_MOVE_JOYSTICK2_1 = 0x032;
    public final static int MSG_ACTION_UP_JOYSTICK2_1 = 0x033;
    public final static int MSG_ACTION_DOWN_JOYSTICK2_2 = 0x041;
    public final static int MSG_ACTION_MOVE_JOYSTICK2_2 = 0x042;
    public final static int MSG_ACTION_UP_JOYSTICK2_2 = 0x043;

    public final static int MSG_ACTION_SWIPE = 0x010;


    public final static int KEYCODE_JOYSTICK_L = 0x10001;
    public final static int KEYCODE_JOYSTICK_R = 0x10002;
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            final MotionEvent event = (MotionEvent)msg.obj;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    if (event != null) mInst.sendPointerSync(event);
                }
            }).start();
        }
    };
    List<GamePadEvent> usedList = new ArrayList<GamePadEvent>();
    Instrumentation mInst = new Instrumentation();
    ReentrantLock lock = new ReentrantLock();

    public boolean bJoystickLFirst = true;
    public boolean bPointer2Mode = false;

    public GameSurfaceView(Context context,String packageName,boolean bTestMode) {
        super(context);
        Log.i(TAG,"GameSurfaceView constructor enter...");

        mContext = context;
        mPackageName = packageName;
        bSelfTestMode = bTestMode;

        mHolder = getHolder(); // 获得SurfaceHolder对象
        mHolder.addCallback(this); // 为SurfaceView添加状态监听
    }

    public GameSurfaceView(Context context, String packageName) {
        super(context);
        Log.i(TAG,"GameSurfaceView constructor enter...");

        mContext = context;
        mPackageName = packageName;
        bSelfTestMode = false;

        mHolder = getHolder(); // 获得SurfaceHolder对象
        mHolder.addCallback(this); // 为SurfaceView添加状态监听
    }

    /**
     * 当SurfaceView创建的时候，调用此函数
     */
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Log.i(TAG,"surfaceCreated enter...");

        //根据packageName解析gamelayout布局文件
        String xmlpath = GameLayout.DEFAULT_GAMELAYOUT_PATH+mPackageName +GameLayout.XML_SUFFIX;
        File f = new File(xmlpath);
        if(f.exists()){
            Log.i(TAG,"游戏对应xml布局文件存在");
            game = new GameLayout(xmlpath);
            game.parse();

            Joystick joystick_L = game.getJoystick("JOYSTICK_L");
            Joystick joystick_R = game.getJoystick("JOYSTICK_R");
            originalX_L = joystick_L.getOriginal().getX();
            originalY_L = joystick_L.getOriginal().getY();
            originalX_R = joystick_R.getOriginal().getX();
            originalY_R = joystick_R.getOriginal().getY();
            radius_L = joystick_L.getRadius();
            radius_R = joystick_R.getRadius();
            type_L = joystick_L.getType();
            type_R = joystick_R.getType();
            response_L = joystick_L.getResponse();
            response_R = joystick_R.getResponse();

            System.out.println("type_L:"+type_L+",type_R:"+type_R);
        }else{
            Log.e(TAG,"游戏对应xml布局文件不存在!!!");
        }

        //setZOrderOnTop(true);
        setZOrderMediaOverlay(true);
        getHolder().setFormat(PixelFormat.TRANSLUCENT);

        if(bSelfTestMode) {
            p = new Paint(); // 创建一个画笔对象
            p.setColor(Color.WHITE); // 设置画笔的颜色为白色
            p.setTextSize(50);
            //setFocusable(true); // 设置焦点
            //setFocusableInTouchMode(true);
            //requestFocus();
            t = new Thread(this); // 创建一个线程对象
            isRunning = true; // 把线程运行的标识设置成true
            t.start(); // 启动线程
        }
    }

    /**
     * 当SurfaceView的视图发生改变的时候，调用此函数
     */
    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width,
                               int height) {
        Log.i(TAG,"surfaceChanged enter...");
    }

    /**
     * 当SurfaceView销毁的时候，调用此函数
     */
    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.i(TAG,"surfaceDestroyed enter...");
        isRunning = false; // 把线程运行的标识设置成false
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        Log.i(TAG,"on touch event...");
        return false;
    }

    public static final int MOTITONEVENT_BUFFSIZE = 10;
    private boolean initFlag = true;
    private double[] buffer_x = new double[MOTITONEVENT_BUFFSIZE];
    private double[] buffer_y = new double[MOTITONEVENT_BUFFSIZE];
    private double[] buffer_z = new double[MOTITONEVENT_BUFFSIZE];
    private double[] buffer_rz = new double[MOTITONEVENT_BUFFSIZE];
    private int loc = 0;
    private int loc_prev = 0;
    private long recordKeyDownTime = 0;
    private int recordKeyCode = 0;

    public void initMotionEventBuff(){
        for(int i=0;i<MOTITONEVENT_BUFFSIZE;i++){
            buffer_x[i] = 0;
            buffer_y[i] = 0;
            buffer_z[i] = 0;
            buffer_rz[i] = 0;
        }
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent event){
        double x,y,z,rz,rx,ry;
        int ix,iy,iz,irz;
        String keycodelabel = "";
        String tag = "GenericMotionEvent";

        //左右摇杆
        /*
        x = event.getAxisValue(MotionEvent.AXIS_X);
        y = event.getAxisValue(MotionEvent.AXIS_Y);
        z = event.getAxisValue(MotionEvent.AXIS_Z);
        rz = event.getAxisValue(MotionEvent.AXIS_RZ);
        */
        x = event.getAxisValue(MotionEvent.AXIS_Z);
        y = event.getAxisValue(MotionEvent.AXIS_RZ);
        z = event.getAxisValue(MotionEvent.AXIS_X);
        rz = event.getAxisValue(MotionEvent.AXIS_Y);

        rx = event.getAxisValue(MotionEvent.AXIS_RX);
        ry = event.getAxisValue(MotionEvent.AXIS_RY);

        Log.i("AXIS",String.format("GenericMotionEvent:\t%f,\t%f,\t%f,\t%f,\t%f,\t%f",(double)Math.round(x*100)/100,(double)Math.round(y*100)/100,(double)Math.round(z*100)/100,(double)Math.round(rz*100)/100,(double)Math.round(rx*100)/100,(double)Math.round(ry*100)/100));
        Log.i("AXIS",String.format("max:%f,%f,%f",Math.max(abs(x),abs(y)),Math.max(abs(z),abs(rz)),Math.max(abs(rx),abs(ry))));

        Log.i("JOYSTICK_L",""+x+","+y);
        Log.i("JOYSTICK_R",""+z+","+rz);

        if(KeycodeMap.getMode() == KeycodeMap.MODE_LANMAO){
            //x = event.getAxisValue(MotionEvent.AXIS_RZ);
            //y = event.getAxisValue(MotionEvent.AXIS_Z);
            //z = event.getAxisValue(MotionEvent.AXIS_Y);
            //rz = event.getAxisValue(MotionEvent.AXIS_X);
        }

        if(initFlag){
            initMotionEventBuff();
            initFlag = false;
        }

        buffer_x[loc] = x;
        buffer_y[loc] = y;
        buffer_z[loc] = z;
        buffer_rz[loc] = rz;

        analysis_L(buffer_x,buffer_y);
        analysis_R(buffer_z,buffer_rz);

        ix = (int)(radius_L*x);iy=(int)(radius_L*y);
        iz = (int)(radius_R*z);irz=(int)(radius_R*rz);

        int joystickType = mDpad.getJoystickType(event);
        if (joystickType == Dpad.JOYSTICK_L) {
            Log.i("Joystick","检测到左摇杆操作");
            if(type_L.equals(GameLayout.TYPE_JOYSTICK_STANDARD)) {
                if (flagJoystickL == 0) {
                    Log.i(TAG, "L:DOWN");
                    flagJoystickL = 1;
                    down(KEYCODE_JOYSTICK_L,originalX_L + ix, originalY_L + iy);
                } else if (flagJoystickL != 0) {
                    Log.i(TAG, "L:MOVING");
                    flagJoystickL = 2;
                    down(KEYCODE_JOYSTICK_L, originalX_L + ix, originalY_L + iy);
                }
            }else if(type_L.equals(GameLayout.TYPE_JOYSTICK_DIRECTION)){
                if (flagJoystickL == 0) {
                    Log.i(TAG, "L:DOWN");
                    flagJoystickL = 1;
                    down(KEYCODE_JOYSTICK_L,originalX_L + ix, originalY_L + iy);
                } else if (flagJoystickL != 0) {
                    Log.i(TAG, "L:MOVING");
                    if(turnback_L()) {
                        System.out.println("turn back L...");
                        flagJoystickL = 0;
                        up(KEYCODE_JOYSTICK_L, originalX_L + ix, originalY_L + iy);
                    }else {
                        flagJoystickL = 2;
                        down(KEYCODE_JOYSTICK_L, originalX_L + ix, originalY_L + iy);
                    }
                }
            }

            //同时控制双摇杆时，需要判断另一个摇杆状态
            if (flagJoystickR != 0) {
                Log.i(tag, "R:UP");
                flagJoystickR = 0;
                up(KEYCODE_JOYSTICK_R, originalX_R + iz, originalY_R + irz);
            }
        } else if (joystickType == Dpad.JOYSTICK_R) {
            Log.i("Joystick","检测到右摇杆操作");
            if(type_R.equals(GameLayout.TYPE_JOYSTICK_STANDARD)) {
                if (flagJoystickR == 0) {
                    Log.i(tag, "R:DOWN");
                    flagJoystickR = 1;
                    down(KEYCODE_JOYSTICK_R, originalX_R + iz, originalY_R + irz);
                } else if (flagJoystickR != 0) {
                    Log.i(tag, "R:MOVING");
                    flagJoystickR = 2;
                    down(KEYCODE_JOYSTICK_R, originalX_R + iz, originalY_R + irz);
                }
            }else if(type_R.equals(GameLayout.TYPE_JOYSTICK_DIRECTION)){
                if (flagJoystickR == 0) {
                    Log.i(tag, "R:DOWN");
                    flagJoystickR = 1;
                    down(KEYCODE_JOYSTICK_R, originalX_R + iz, originalY_R + irz);
                } else if (flagJoystickR != 0) {
                    Log.i(tag, "R:MOVING");
                    if(!turnback_R()){
                        flagJoystickR = 2;
                        down(KEYCODE_JOYSTICK_R, originalX_R + iz, originalY_R + irz);
                    }else{
                        flagJoystickR = 0;
                        up(KEYCODE_JOYSTICK_R, originalX_R + iz, originalY_R + irz);
                    }
                }
            }


            //同时控制双摇杆时，需要判断另一个摇杆状态
            if (flagJoystickL != 0) {
                Log.i(tag, "L:UP");
                flagJoystickL = 0;
                up(KEYCODE_JOYSTICK_L, originalX_L + ix, originalY_L + iy);
            }
        } else if(joystickType == Dpad.JOYSTICK_L+Dpad.JOYSTICK_R){
            Log.i("Joystick","检测到左右摇杆同时操作");
            if(type_L.equals(GameLayout.TYPE_JOYSTICK_STANDARD)) {
                if (flagJoystickL == 0) {
                    Log.i(TAG, "L:DOWN");
                    flagJoystickL = 1;
                    down(KEYCODE_JOYSTICK_L,originalX_L + ix, originalY_L + iy);
                } else if (flagJoystickL != 0) {
                    Log.i(TAG, "L:MOVING");
                    flagJoystickL = 2;
                    down(KEYCODE_JOYSTICK_L,originalX_L + ix, originalY_L + iy);
                }
            }

            if(type_R.equals(GameLayout.TYPE_JOYSTICK_STANDARD)) {
                if (flagJoystickR == 0) {
                    Log.i(tag, "R:DOWN");
                    flagJoystickR = 1;
                    down(KEYCODE_JOYSTICK_R, originalX_R + iz, originalY_R + irz);
                } else if (flagJoystickR != 0) {
                    Log.i(tag, "R:MOVING");
                    flagJoystickR = 2;
                    down(KEYCODE_JOYSTICK_R,originalX_R + iz, originalY_R + irz);
                }
            }

        } else {
            Log.i("Joystick","未检测到摇杆操作");
            if(type_L.equals(GameLayout.TYPE_JOYSTICK_STANDARD)) {
                if (flagJoystickL != 0) {
                    Log.i(tag, "L:UP");
                    flagJoystickL = 0;
                    up(KEYCODE_JOYSTICK_L, originalX_L + ix, originalY_L + iy);
                }
            }

            if(type_R.equals(GameLayout.TYPE_JOYSTICK_STANDARD)) {
                if (flagJoystickR != 0) {
                    Log.i(tag, "R:UP");
                    flagJoystickR = 0;
                    up(KEYCODE_JOYSTICK_R, originalX_R + iz, originalY_R + irz);
                }
            }
        }

        loc_prev = loc;
        loc = (loc+1)%MOTITONEVENT_BUFFSIZE;
        return true;
    }

    public boolean analysis_L(double[] buff_x,double[] buff_y){
        return true;
    }

    public boolean analysis_R(double[] buff_z,double[] buff_rz){
        return true;
    }

    public boolean turnback_L(){
        double curr_x = buffer_x[loc];
        double curr_y = buffer_y[loc];
        double prev_x = buffer_x[loc_prev];
        double prev_y = buffer_y[loc_prev];

        double curr_powsum = (Math.pow(curr_x,2)+Math.pow(curr_y,2));
        double prev_powsum = (Math.pow(prev_x,2)+Math.pow(prev_y,2));
        double thre_powsum = (Math.pow(Dpad.validJoystickThresholdX,2)+Math.pow(Dpad.validJoystickThresholdY,2));
        if(curr_powsum > prev_powsum && curr_powsum > thre_powsum){
            return false;
        }else{
            return true;
        }
    }

    public boolean turnback_R(){
        double curr_z = buffer_z[loc];
        double curr_rz = buffer_rz[loc];
        double prev_z = buffer_z[loc_prev];
        double prev_rz = buffer_rz[loc_prev];

        double curr_powsum = (Math.pow(curr_z,2)+Math.pow(curr_rz,2));
        double prev_powsum = (Math.pow(prev_z,2)+Math.pow(prev_rz,2));
        double thre_powsum = (Math.pow(Dpad.validJoystickThresholdX,2)+Math.pow(Dpad.validJoystickThresholdY,2));
        if(curr_powsum > prev_powsum && curr_powsum > thre_powsum){
            return false;
        }else{
            return true;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event){
        Log.i(TAG,"dispatchKeyEvent enter...");
        if(event.getKeyCode() == KeyEvent.KEYCODE_BACK){
            this.setVisibility(View.GONE);
            return false;
        }

        Log.i(TAG,"dispatchKeyEvent done.");
        return super.dispatchKeyEvent(event);
    }


    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event){
        Log.i(TAG, "onKeyUp:"+keyCode);
        dpadKeyCode = 0xffff;

        doActionForKeyUp(keyCode, event.getAction());

        return true;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Log.d(TAG,"onKeyDown:"+keyCode);
        dpadKeyCode = keyCode;

        long currTime = System.currentTimeMillis();
        if(currTime - recordKeyDownTime > 50){//50ms内判断是否同时按下多个键
            recordKeyDownTime = currTime;
            recordKeyCode = keyCode;
        }else{
            if(recordKeyCode != keyCode) {
                System.out.println("检测连续按不同键："+recordKeyCode+","+keyCode);
                //按组合键处理

            }else{
                System.out.println("检测连续按相同键");
                //不处理
            }
        }

        doActionForKeyUp(keyCode, event.getAction());

        return true;
    }

    public boolean doActionForKeyUp(int keyCode,int action){
        String keycodelabel = KeycodeMap.getKey(keyCode);
        if(game != null){
            Btn btn = game.getBtnsMap().get(keycodelabel);
            if(btn != null){
                if (btn.getAction().equals(GameLayout.ACTION_CLICK)) {
                    if(action == MotionEvent.ACTION_DOWN) {
                        if (btn.getType().equals(GameLayout.TYPE_MULTI)) {//该按钮为multi多点复用，需要处理index
                            Log.i(TAG, "当前index：" + btn.getPointIndex());
                            btn.increasePointIndex();
                            Log.i(TAG, "下个index：" + btn.getPointIndex());
                        }
                    }

                    Point point = btn.getPoint();
                    if(point == null) return false;
                    Log.i(TAG,"x:"+point.getX()+",:"+point.getY());
                    if(action == MotionEvent.ACTION_UP){
                        up(keyCode,point.getX(), point.getY());
                    }else if(action == MotionEvent.ACTION_DOWN){
                        down(keyCode,point.getX(), point.getY());
                    }
                } else if (btn.getAction().equals(GameLayout.ACTION_SWIPE)) {

                }

                return true;
            }else{
                Log.e(TAG,"Btn NOT defined");
                return false;
            }
        }else{
            Log.i(TAG,"[KeyUp]game is null");

            return false;
        }
    }

    @Override
    public void run() {

        while (isRunning == true) {
            Draw(); // 调用自定义画画方法
            try {
                Thread.sleep(10); // 让线程休息50毫秒
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void Draw() {
        mCanvas = mHolder.lockCanvas(); // 获得画布对象，开始对画布画画
        if(mCanvas != null) {
            //mCanvas.drawRGB(0, 0x80, 0); // 把画布填充为绿色
            if (circleX != 0xffff && circleY != 0xffff) {
                mCanvas.drawCircle(circleX, circleY, circleR, p); // 画一个圆
            }

            if (dpadKeyCode != 0xffff) {
                mCanvas.drawText("" + dpadKeyCode, 500, 500, p);
            }

            mHolder.unlockCanvasAndPost(mCanvas); // 完成画画，把画布显示在屏幕上
        }
    }

    public void down(int keycode, int x, int y) {
        MotionEvent event = null;
        //lock.lock();
        try {
            GamePadEvent target = new GamePadEvent(keycode, x, y, MotionEvent.ACTION_DOWN);
            if (usedList.size() > 0) {
                int i;
                boolean found = false;
                for (i = 0; i < usedList.size(); i++) {//写了10就是支持10个点
                    GamePadEvent gpe = usedList.get(i);
                    if (gpe.keycode == keycode) {
                        System.out.println("[down]found:" + i);
                        Log.i("updown","move:"+keycode);
                        target.sid = i;
                        target.downtime = gpe.downtime;
                        target.eventtime = SystemClock.uptimeMillis();
                        target.action = MotionEvent.ACTION_MOVE;
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    Log.i("updown","down:"+keycode);
                    target.sid = usedList.size() + 1;
                    target.downtime = SystemClock.uptimeMillis();
                    target.eventtime = target.downtime;
                    usedList.add(target);
                }

            } else {
                Log.i("updown","down:"+keycode);
                target.sid = 0;
                target.downtime = SystemClock.uptimeMillis();
                target.eventtime = target.downtime;
                usedList.add(0, target);
            }

            event = getMultiEvent(target);
            //Message msg = Message.obtain();
            //msg.obj = event;
            //handler.sendMessage(msg);
        }finally{
            //lock.unlock();
        }

        Message msg = Message.obtain();
        msg.obj = event;
        handler.sendMessage(msg);
    }

    public void up(int keycode, int x, int y) {
        MotionEvent event = null;
        //lock.lock();
        try {
            GamePadEvent target = new GamePadEvent(keycode, x, y, MotionEvent.ACTION_UP);
            //把新的target 添加到usedlist里面去，并且设置sid
            for (int i = 0; i < usedList.size(); i++) {
                GamePadEvent gpe = usedList.get(i);
                if (target.keycode == gpe.keycode) {
                    Log.i("updown","up:"+keycode);
                    target.sid = gpe.sid;
                    target.downtime = gpe.downtime;
                    target.eventtime = SystemClock.uptimeMillis();
                    target.action = MotionEvent.ACTION_UP;
                    event = getMultiEvent(target);
                    usedList.remove(i);

                    //Message msg = Message.obtain();
                    //msg.obj = event;
                    //handler.sendMessage(msg);

                    break;
                }
            }
        }finally {
            //lock.unlock();
        }

        if(event != null){
            Message msg = Message.obtain();
            msg.obj = event;
            handler.sendMessage(msg);
        }
    }

    private MotionEvent getMultiEvent(GamePadEvent target) {
        int action;
        int listsize;

        listsize = usedList.size();
        if (listsize == 0) {
            System.out.println("NO event found!");
            return null;
        }

        System.out.println("size:"+listsize);
        //记录当前按下的点的action是move，up，down，判断是1个点还是多个点
        if (target.action == MotionEvent.ACTION_DOWN) {
            action = listsize > 1 ? MotionEvent.ACTION_POINTER_DOWN : MotionEvent.ACTION_DOWN;
        }else if (target.action == MotionEvent.ACTION_UP) {
            action = listsize > 1 ? MotionEvent.ACTION_POINTER_UP : MotionEvent.ACTION_UP;
        }else{
            action = MotionEvent.ACTION_MOVE;
        }

        MotionEvent.PointerProperties[] pointerProperties = new MotionEvent.PointerProperties[listsize];
        MotionEvent.PointerCoords[] pointerCoords = new MotionEvent.PointerCoords[listsize];
        int index = 0;
        int targetIndex = 0;
        for (GamePadEvent gamePadEvent : usedList) {
            if (gamePadEvent.keycode == target.keycode) {//存在表明是ACTION_MOVE
                targetIndex = index;//记录当前的按下的点的位置，用作计算最后的action

                MotionEvent.PointerCoords pointerCoord = new MotionEvent.PointerCoords();
                pointerCoord.pressure = 1;
                pointerCoord.x = target.x;
                pointerCoord.y = target.y;
                pointerCoords[index] = pointerCoord;

                MotionEvent.PointerProperties pointerPropertie = new MotionEvent.PointerProperties();
                pointerPropertie.id = index;//保存的id
                pointerPropertie.toolType = MotionEvent.TOOL_TYPE_FINGER;
                pointerProperties[index] = pointerPropertie;
            }else{
                MotionEvent.PointerCoords pointerCoord = new MotionEvent.PointerCoords();
                pointerCoord.pressure = 1;
                pointerCoord.x = gamePadEvent.x;
                pointerCoord.y = gamePadEvent.y;
                pointerCoords[index] = pointerCoord;

                MotionEvent.PointerProperties pointerPropertie = new MotionEvent.PointerProperties();
                pointerPropertie.id = index;//保存的id
                pointerPropertie.toolType = MotionEvent.TOOL_TYPE_FINGER;
                pointerProperties[index] = pointerPropertie;
            }

            ++index;
        }

        int actionPoint = (action != MotionEvent.ACTION_MOVE) ? (action + (targetIndex << MotionEvent.ACTION_POINTER_INDEX_SHIFT)) : MotionEvent.ACTION_MOVE;
        long downTime = target.downtime;
        long eventTime = target.eventtime;
        //System.out.println("[getMultiEvent]targetIndex="+targetIndex+",action="+MotionEvent.actionToString(actionPoint)+",downtime="+downTime+",eventtime="+eventTime);
        /**
         * Create a new MotionEvent, filling in all of the basic values that
         * define the motion.
         *
         * @param downTime The time (in ms) when the user originally pressed down to start
         * a stream of position events.  This must be obtained from {@link SystemClock#uptimeMillis()}.
         * @param eventTime The the time (in ms) when this specific event was generated.  This
         * must be obtained from {@link SystemClock#uptimeMillis()}.
         * @param action The kind of action being performed, such as {@link #ACTION_DOWN}.
         * @param pointerCount The number of pointers that will be in this event.
         * @param pointerProperties An array of <em>pointerCount</em> values providing
         * a {@link PointerProperties} property object for each pointer, which must
         * include the pointer identifier.
         * @param pointerCoords An array of <em>pointerCount</em> values providing
         * a {@link PointerCoords} coordinate object for each pointer.
         * @param metaState The state of any meta / modifier keys that were in effect when
         * the event was generated.
         * @param buttonState The state of buttons that are pressed.
         * @param xPrecision The precision of the X coordinate being reported.
         * @param yPrecision The precision of the Y coordinate being reported.
         * @param deviceId The id for the device that this event came from.  An id of
         * zero indicates that the event didn't come from a physical device; other
         * numbers are arbitrary and you shouldn't depend on the values.
         * @param edgeFlags A bitfield indicating which edges, if any, were touched by this
         * MotionEvent.
         * @param source The source of this event.
         * @param flags The motion event flags.
         */
        return MotionEvent.obtain( downTime,
                eventTime,
                actionPoint,
                usedList.size(),
                pointerProperties,
                pointerCoords,
                0, //metaState
                0, //buttonState
                1, //xPrecision
                1, //yPrecision
                0, //deviceId
                0, //edgeFlags
                InputDevice.SOURCE_TOUCHSCREEN,
                0);
    }
}

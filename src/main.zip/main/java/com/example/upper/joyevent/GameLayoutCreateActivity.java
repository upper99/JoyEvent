package com.example.upper.joyevent;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GameLayoutCreateActivity extends AppCompatActivity implements View.OnClickListener {
    EditText et_appname;
    EditText et_packagename;

    EditText btn_b;
    EditText btn_x;
    EditText btn_y;
    EditText btn_up;
    EditText btn_left;
    EditText btn_right;
    EditText btn_lt;
    EditText btn_rt;
    EditText joystick_l;
    EditText joystick_r;

    EditText et_coordinate_btn_b;
    EditText et_coordinate_btn_x;
    EditText et_coordinate_btn_y;
    EditText et_coordinate_btn_up;
    EditText et_coordinate_btn_lt;
    EditText et_coordinate_btn_rt;
    EditText et_coordinate_btn_left;
    EditText et_coordinate_btn_right;
    EditText et_radius_joystickL;
    EditText et_radius_joystickR;
    EditText et_coordinate_original_joystickL;
    EditText et_coordinate_original_joystickR;
    Button btn_generate_xml;
    GameLayout gameLayout;
    HashMap<EditText,String> map = new HashMap<EditText,String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_layout_create);

        gameLayout = new GameLayout();

        et_appname = (EditText)findViewById(R.id.et_appname);
        et_packagename = (EditText)findViewById(R.id.et_packagename);

        btn_b = (EditText)findViewById(R.id.btn_b);
        btn_x = (EditText)findViewById(R.id.btn_x);
        btn_y = (EditText)findViewById(R.id.btn_y);
        btn_up = (EditText)findViewById(R.id.btn_up);
        btn_left = (EditText)findViewById(R.id.btn_left);
        btn_right = (EditText)findViewById(R.id.btn_right);
        btn_lt = (EditText)findViewById(R.id.btn_lt);
        btn_rt = (EditText)findViewById(R.id.btn_rt);
        joystick_l = (EditText)findViewById(R.id.joystick_l);
        joystick_r = (EditText)findViewById(R.id.joystick_r);

        et_coordinate_btn_b = (EditText)findViewById(R.id.et_btn_b);
        et_coordinate_btn_x = (EditText)findViewById(R.id.et_btn_x);
        et_coordinate_btn_y = (EditText)findViewById(R.id.et_btn_y);
        et_coordinate_btn_up = (EditText)findViewById(R.id.et_btn_up);
        et_coordinate_btn_left = (EditText)findViewById(R.id.et_btn_left);
        et_coordinate_btn_right = (EditText)findViewById(R.id.et_btn_right);
        et_coordinate_btn_lt = (EditText)findViewById(R.id.et_btn_lt);
        et_coordinate_btn_rt = (EditText)findViewById(R.id.et_btn_rt);
        et_radius_joystickL = (EditText)findViewById(R.id.et_joystickL_radius);
        et_radius_joystickR = (EditText)findViewById(R.id.et_joystickR_radius);
        et_coordinate_original_joystickL = (EditText)findViewById(R.id.et_joystickL_original);
        et_coordinate_original_joystickR = (EditText)findViewById(R.id.et_joystickR_original);

        debug(1);

        //按键：一个EditText对应一个按键名称(其它属性基本上可以从EditText间接获取)
        map.put(et_coordinate_btn_b,btn_b.getText().toString());
        map.put(et_coordinate_btn_x,btn_x.getText().toString());
        map.put(et_coordinate_btn_y,btn_y.getText().toString());
        map.put(et_coordinate_btn_up,btn_up.getText().toString());
        map.put(et_coordinate_btn_left,btn_left.getText().toString());
        map.put(et_coordinate_btn_right,btn_right.getText().toString());
        map.put(et_coordinate_btn_lt,btn_lt.getText().toString());
        map.put(et_coordinate_btn_rt,btn_rt.getText().toString());

        //摇杆：多个EditText对应一个摇杆名称
        map.put(et_radius_joystickL,joystick_l.getText().toString());
        map.put(et_coordinate_original_joystickL,joystick_l.getText().toString());
        map.put(et_radius_joystickR,joystick_r.getText().toString());
        map.put(et_coordinate_original_joystickR,joystick_r.getText().toString());

        btn_generate_xml = (Button)findViewById(R.id.btn_generate_xml);
        btn_generate_xml.setOnClickListener(this);


        //申请权限
        //verifyStoragePermissions(this);
    }

    public void verifyStoragePermissions(Activity activity) {
        String[] PERMISSIONS_STORAGE = {
                "android.permission.READ_EXTERNAL_STORAGE",
                "android.permission.WRITE_EXTERNAL_STORAGE" };
        try {
            //检测是否有写的权限
            int permission = ActivityCompat.checkSelfPermission(activity,
                    "android.permission.WRITE_EXTERNAL_STORAGE");
            if (permission != PackageManager.PERMISSION_GRANTED) {
                // 没有写的权限，去申请写的权限，会弹出对话框
                ActivityCompat.requestPermissions(activity, PERMISSIONS_STORAGE,0);
                ActivityCompat.requestPermissions(activity, PERMISSIONS_STORAGE,1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void debug(int mode){
        switch(mode){
            case 1:
                et_appname.setText("测试游戏1");
                et_packagename.setText("abc.dce.ddd");

                et_coordinate_btn_b.setText("(111,222)");
                et_coordinate_btn_x.setText("(222,333)");
                et_coordinate_btn_y.setText("(333,444)/(555,666)");
                et_coordinate_btn_up.setText("(777,888)");
                et_coordinate_btn_left.setText("(999,800)");
                et_coordinate_btn_right.setText("(100,200)");
                et_coordinate_btn_rt.setText("(888,888)");
                et_coordinate_btn_lt.setText("(999,200)");

                et_radius_joystickL.setText("100");
                et_coordinate_original_joystickL.setText("(400,500)");
                et_radius_joystickR.setText("100");
                et_coordinate_original_joystickR.setText("(600,700)");
            break;
            case 2:
                et_coordinate_btn_b.setText("(111,222)");
                et_coordinate_btn_x.setText("(222,333)");
                et_coordinate_btn_y.setText("(333,444)");
                et_coordinate_btn_up.setText("(777,888)");
                et_coordinate_btn_left.setText("(999,800)");
                et_coordinate_btn_right.setText("(100,200)");
                et_coordinate_btn_rt.setText("(888,888)");
                et_coordinate_btn_lt.setText("(999,200)");

                et_radius_joystickL.setText("100");
                et_coordinate_original_joystickL.setText("(400,500)");
                et_radius_joystickR.setText("100");
                et_coordinate_original_joystickR.setText("(600,700)");
            break;
        }
    }

    public String textval(EditText et){
        String val = et.getText().toString().trim();
        if(val.equals("")){
            return null;
        }else{
            return val;
        }
    }

    //根据字符串"（x,y）"解析出Point
    public Point parsePoint(String corrdirate){
        Point retPoint = null;
        String pattern = "^\\((\\d+),\\s*(\\d+)\\)$";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(corrdirate);
        if(m.find()){
            retPoint = new Point();
            retPoint.setX(Integer.parseInt(m.group(1)));
            retPoint.setX(Integer.parseInt(m.group(2)));
            System.out.println(m.group(1)+","+m.group(2));
        }
        return retPoint;
    }

    //根据"(x1,y1)/(x2,y2)"解析
    public ArrayList<Point> parsePoints(String corrdirates){
        ArrayList<Point> points = new ArrayList<Point>();
        if(corrdirates.contains("/")) {
            String[] arr = corrdirates.split("/");
            for (int i = 0; i < arr.length; i++) {
                Point p = parsePoint(arr[i]);
                if (p != null) points.add(p);
            }
        }else{
            Point p = parsePoint(corrdirates);
            points.add(p);
        }

        return points;
    }

    public void addBtnForGameLayout(EditText et){
        String tmpval = textval(et);
        String btnName = map.get(et);//"BUTTON_B";
        if(tmpval != null){
            if(tmpval.contains("/")){//多点
                Btn btn = new Btn();
                btn.setName(btnName);
                btn.setAction("click");//暂时只支持click
                btn.setType("multi");
                ArrayList<Point> points = parsePoints(tmpval);
                btn.setPointsNum(points.size());
                btn.setPointList(points);
                gameLayout.addBtn(btnName,btn);
            }else{//单点
                Btn btn = new Btn();
                btn.setName(btnName);
                btn.setAction("click");//暂时只支持click
                btn.setType("single");
                ArrayList<Point> points = parsePoints(tmpval);
                btn.setPointList(points);
                gameLayout.addBtn(btnName,btn);
            }
        }
    }

    public void addJoystickForGameLayout(EditText et_radius,EditText et_coordinate){
        String strRadius = textval(et_radius);
        String strCoordinate = textval(et_coordinate);
        String joystickName = map.get(et_radius);
        if(strRadius != null && strCoordinate != null){
            Joystick joystick = new Joystick();
            joystick.setName(joystickName);
            joystick.setRadius(Integer.parseInt(strRadius));
            Point p = parsePoint(strCoordinate);
            joystick.setOriginal(p);

            gameLayout.addJoystick(joystickName,joystick);
        }
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btn_generate_xml:
                String tmpval = null;
                tmpval = textval(et_appname);
                if(tmpval != null){
                    gameLayout.setGameNameCh(tmpval);
                }

                tmpval = textval(et_packagename);
                if(tmpval != null){
                    gameLayout.setGamePackage(tmpval);
                }

                addBtnForGameLayout(et_coordinate_btn_b);
                addBtnForGameLayout(et_coordinate_btn_x);
                addBtnForGameLayout(et_coordinate_btn_y);
                addBtnForGameLayout(et_coordinate_btn_up);
                addBtnForGameLayout(et_coordinate_btn_left);
                addBtnForGameLayout(et_coordinate_btn_right);
                addBtnForGameLayout(et_coordinate_btn_lt);
                addBtnForGameLayout(et_coordinate_btn_rt);

                addJoystickForGameLayout(et_radius_joystickL,et_coordinate_original_joystickL);
                addJoystickForGameLayout(et_radius_joystickR,et_coordinate_original_joystickR);

                //parsePoint("(100,200)");
                //parsePoints("(100,200)/(200,300)/(400,400)");
                gameLayout.dump();

                try {
                    gameLayout.create(gameLayout.getGamePackage());
                } catch (IOException e) {
                    e.printStackTrace();
                }


                break;
        }
    }
}

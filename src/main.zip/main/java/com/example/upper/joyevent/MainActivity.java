package com.example.upper.joyevent;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.w3c.dom.Text;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    public static final String TAG = "MainActivity";
    private static final Intent sSettingsIntent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
    private Button btnEnableService;
    private Button btnPreview;
    private Button btnCreate;
    private Button btnGameTest;
    private RadioGroup radioGroup;
    private TextView tv_keycode;
    private TextView tv_showresult;
    private RadioGroup rg_joystick;
    private Spinner gameslist;
    private List<String> data_list;
    private ArrayAdapter<String> arr_adapter;
    private boolean bWhetherShowKeycode = false;
    private static boolean isExist = false;
    private boolean bTestMode = false;
    private String gamePackageName = "default";
    private GameSurfaceView mySurfaceView;
    private WindowManager.LayoutParams params;
    private WindowManager wm;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            isExist = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //requestWindowFeature(Window.FEATURE_NO_TITLE);

        btnEnableService = (Button) findViewById(R.id.btn_enableService);
        btnEnableService.setOnClickListener(this);

        btnCreate = (Button)findViewById(R.id.btn_create);
        btnCreate.setOnClickListener(this);

        btnGameTest = (Button) findViewById(R.id.btn_gametest);
        btnGameTest.setOnClickListener(this);

        btnPreview = (Button) findViewById(R.id.btn_preview);
        btnPreview.setOnClickListener(this);

        gameslist = (Spinner) findViewById(R.id.spinner);

        //从/sdcard/gamelayout/中解析出“游戏名称-包名”映射关系
        HashMap<String,String> gamemap = new HashMap<String,String>();
        gamemap.put("com.tencent.tmgp.pubgmhd","绝地求生");
        gamemap.put("com.tencent.tmgp.sgame","王者荣耀");

        //data_list = new ArrayList<String>(gamemap.keySet().toArray());


        //数据
        data_list = new ArrayList<String>();
        data_list.add("绝地求生");//0
        data_list.add("王者荣耀");//1
        data_list.add("第五人格");//2
        data_list.add("自定义1");
        data_list.add("自定义2");
        data_list.add("自定义3");


        //适配器
        arr_adapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, data_list);
        //设置样式
        arr_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //加载适配器
        gameslist.setAdapter(arr_adapter);
        gameslist.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {//选择item的选择点击监听事件
            public void onItemSelected(AdapterView<?> arg0,View arg1,int pos, long id) {
                // TODO Auto-generated method stub
                switch(pos){
                    case 0:
                        gamePackageName = "com.tencent.tmgp.pubgmhd";
                        break;
                    case 1:
                        gamePackageName = "com.tencent.tmgp.sgame";
                        break;
                    case 2:
                    default:
                        gamePackageName = "default";
                        break;
                }

            }

            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });

        //dispToast("当前选中游戏包名："+gamePackageName);

        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        params = new WindowManager.LayoutParams();
        params.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_ATTACHED_IN_DECOR

                | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;//解决软键盘不显示问题
                //| WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;//确保surfaceview不会拦截activity的返回键处理

        // 设置悬浮窗的长和宽
        params.width = wm.getDefaultDisplay().getWidth();
        params.height = wm.getDefaultDisplay().getHeight();
        mySurfaceView = new GameSurfaceView(getApplicationContext(),gamePackageName,true);

        //更新支持游戏包名列表
        //MyService.vSupportGamePackage.clear();
        //MyService.vSupportGamePackage.add("com.tencent.tmgp.pubgmhd");

        rg_joystick = findViewById(R.id.rg_joystick);
        rg_joystick.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int id = group.getCheckedRadioButtonId();
                switch(checkedId){
                    case R.id.rb_betop:
                        System.out.println("选择betop");
                        KeycodeMap.updateKeycodeMap(KeycodeMap.MODE_BETOP);
                        break;
                    case R.id.rb_lanmao:
                        System.out.println("选择lanmao");
                        KeycodeMap.updateKeycodeMap(KeycodeMap.MODE_LANMAO);
                        break;
                }

                RadioButton rb = findViewById(checkedId);
                dispToast("current joystick mode:"+rb.getText());
            }
        });
    }

    @Override
    protected void onStart(){
        super.onStart();

        if(serviceIsRunning()){
            Log.d(TAG, "service is running");
            btnEnableService.setText("关闭辅助服务");
        }else{
            Log.d(TAG, "service is Not running");
            btnEnableService.setText("打开辅助服务");
        }
    }

    private boolean serviceIsRunning() {
        ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> services = am.getRunningServices(Short.MAX_VALUE);
        for (ActivityManager.RunningServiceInfo info : services) {
            Log.d(TAG, info.service.getClassName());
            if (info.service.getClassName().equals(getPackageName() + ".MyService")) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event){
        Log.i(TAG,"MainActivity:dispatchKeyEvent enter...");

        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean onKeyDown(int keycode, KeyEvent event){
        if(bWhetherShowKeycode){
            tv_keycode.setText("当前按键码："+keycode);
            return true;
        }

        if(keycode == event.KEYCODE_BACK) {
            exit();
            return false;
        }

        return false;
    }

    private void exit(){
        if(!isExist){
            isExist = true;
            Toast.makeText(getApplicationContext(),"再按一次退出", Toast.LENGTH_SHORT).show();

            mHandler.sendEmptyMessageDelayed(0,1000);
        }else{
            finish();
            System.exit(0);
        }
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btn_create:
                Intent it = new Intent(this,GameLayoutCreateActivity.class);
                startActivity(it);
                break;
            case R.id.btn_preview:
                tv_showresult.setText("xml文件："+gamePackageName+"\n");
                SAXReader reader = new SAXReader();
                String xmlFilePath = GameLayout.DEFAULT_GAMELAYOUT_PATH+gamePackageName+".xml";

                try {
                    FileInputStream fis = new FileInputStream(new File(xmlFilePath));//打开文件输入流
                    StringBuffer sBuffer = new StringBuffer();
                    DataInputStream dataIO = new DataInputStream(fis);//读取文件数据流
                    String strLine = null;
                    while ((strLine = dataIO.readLine()) != null) {//通过readline按行读取
                        sBuffer.append(strLine + "\n");//strLine就是一行的内容
                    }
                    dataIO.close();
                    fis.close();
                    tv_showresult.append(sBuffer.toString());
                }catch(FileNotFoundException e){
                    e.printStackTrace();
                }catch(IOException e2){
                    e2.printStackTrace();
                }
                break;
            case R.id.btn_gametest:
                if(bTestMode == false) {
                    btnGameTest.setText("自测中...");
                    bTestMode = true;
                    wm.addView(mySurfaceView, params);
                }else{
                    btnGameTest.setText("自测");
                    bTestMode = false;
                    wm.removeView(mySurfaceView);
                }
                break;
            case R.id.btn_enableService:
                startActivity(sSettingsIntent);
                break;
        }
    }

    public void dispToast(String str){
        Toast.makeText(MainActivity.this,str,Toast.LENGTH_SHORT).show();
    }
}
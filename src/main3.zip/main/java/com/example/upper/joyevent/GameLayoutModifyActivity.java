package com.example.upper.joyevent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class GameLayoutModifyActivity extends AppCompatActivity {
    EditText et_appname;
    EditText et_packagename;

    EditText btn_b;
    EditText btn_x;
    EditText btn_y;
    EditText btn_up;
    EditText btn_left;
    EditText btn_right;
    EditText btn_lt;
    EditText btn_rt;
    EditText btn_lpress;
    EditText btn_rpress;
    EditText joystick_l;
    EditText joystick_r;

    EditText et_coordinate_btn_b;
    EditText et_coordinate_btn_x;
    EditText et_coordinate_btn_y;
    EditText et_coordinate_btn_up;
    EditText et_coordinate_btn_lt;
    EditText et_coordinate_btn_rt;
    EditText et_coordinate_btn_left;
    EditText et_coordinate_btn_right;
    EditText et_coordinate_btn_lpress;
    EditText et_coordinate_btn_rpress;
    EditText et_radius_joystickL;
    EditText et_radius_joystickR;
    EditText et_coordinate_original_joystickL;
    EditText et_coordinate_original_joystickR;
    GameLayout gameLayout;

    Button btn_modify_xml;
    HashMap<EditText,String> map = new HashMap<EditText,String>();
    ArrayList<EditText> vEditTextWithPointAttr = new ArrayList<EditText>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_layout_modify);

        Intent intent = getIntent();
        String packageName = intent.getStringExtra("packageName");
        gameLayout = new GameLayout(packageName);

        et_appname = (EditText)findViewById(R.id.et_appname);
        et_packagename = (EditText)findViewById(R.id.et_packagename);

        btn_b = (EditText)findViewById(R.id.btn_b);
        btn_x = (EditText)findViewById(R.id.btn_x);
        btn_y = (EditText)findViewById(R.id.btn_y);
        btn_up = (EditText)findViewById(R.id.btn_up);
        btn_left = (EditText)findViewById(R.id.btn_left);
        btn_right = (EditText)findViewById(R.id.btn_right);
        btn_lt = (EditText)findViewById(R.id.btn_lt);
        btn_rt = (EditText)findViewById(R.id.btn_rt);
        btn_lpress = (EditText)findViewById(R.id.btn_lpress);
        btn_rpress = (EditText)findViewById(R.id.btn_rpress);
        joystick_l = (EditText)findViewById(R.id.joystick_l);
        joystick_r = (EditText)findViewById(R.id.joystick_r);

        et_coordinate_btn_b = (EditText)findViewById(R.id.et_btn_b);
        et_coordinate_btn_x = (EditText)findViewById(R.id.et_btn_x);
        et_coordinate_btn_y = (EditText)findViewById(R.id.et_btn_y);
        et_coordinate_btn_up = (EditText)findViewById(R.id.et_btn_up);
        et_coordinate_btn_left = (EditText)findViewById(R.id.et_btn_left);
        et_coordinate_btn_right = (EditText)findViewById(R.id.et_btn_right);
        et_coordinate_btn_lt = (EditText)findViewById(R.id.et_btn_lt);
        et_coordinate_btn_rt = (EditText)findViewById(R.id.et_btn_rt);
        et_coordinate_btn_lpress = (EditText)findViewById(R.id.et_btn_lpress);
        et_coordinate_btn_rpress = (EditText)findViewById(R.id.et_btn_rpress);
        et_radius_joystickL = (EditText)findViewById(R.id.et_joystickL_radius);
        et_radius_joystickR = (EditText)findViewById(R.id.et_joystickR_radius);
        et_coordinate_original_joystickL = (EditText)findViewById(R.id.et_joystickL_original);
        et_coordinate_original_joystickR = (EditText)findViewById(R.id.et_joystickR_original);

        //按键：一个EditText对应一个按键名称(其它属性基本上可以从EditText间接获取)
        map.put(et_coordinate_btn_b,btn_b.getText().toString());
        map.put(et_coordinate_btn_x,btn_x.getText().toString());
        map.put(et_coordinate_btn_y,btn_y.getText().toString());
        map.put(et_coordinate_btn_up,btn_up.getText().toString());
        map.put(et_coordinate_btn_left,btn_left.getText().toString());
        map.put(et_coordinate_btn_right,btn_right.getText().toString());
        map.put(et_coordinate_btn_lt,btn_lt.getText().toString());
        map.put(et_coordinate_btn_rt,btn_rt.getText().toString());
        map.put(et_coordinate_btn_lpress,btn_lpress.getText().toString());
        map.put(et_coordinate_btn_rpress,btn_rpress.getText().toString());

        //摇杆：多个EditText对应一个摇杆名称
        map.put(et_radius_joystickL,joystick_l.getText().toString());
        map.put(et_coordinate_original_joystickL,joystick_l.getText().toString());
        map.put(et_radius_joystickR,joystick_r.getText().toString());
        map.put(et_coordinate_original_joystickR,joystick_r.getText().toString());

        //具有point属性的EditText
        vEditTextWithPointAttr.add(et_coordinate_btn_b);
        vEditTextWithPointAttr.add(et_coordinate_btn_x);
        vEditTextWithPointAttr.add(et_coordinate_btn_y);
        vEditTextWithPointAttr.add(et_coordinate_btn_up);
        vEditTextWithPointAttr.add(et_coordinate_btn_left);
        vEditTextWithPointAttr.add(et_coordinate_btn_right);
        vEditTextWithPointAttr.add(et_coordinate_btn_lt);
        vEditTextWithPointAttr.add(et_coordinate_btn_rt);
        vEditTextWithPointAttr.add(et_coordinate_btn_lpress);
        vEditTextWithPointAttr.add(et_coordinate_btn_rpress);
        vEditTextWithPointAttr.add(et_coordinate_original_joystickL);
        vEditTextWithPointAttr.add(et_coordinate_original_joystickR);

        btn_modify_xml = findViewById(R.id.btn_modify_xml);
        btn_modify_xml.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    gameLayout.create(null);
                    dispToast("更新成功");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        initData();
    }

    public void initData(){
        et_appname.setText(gameLayout.getGameNameCh());
        et_packagename.setText(gameLayout.getGamePackage());

        //showEditTextPointAttr();

        Point tp = new Point(100,200);
        Point tp2 = new Point(234,455);
        ArrayList<Point> vp = new ArrayList<Point>();
        vp.add(tp);vp.add(tp2);
        System.out.println(formatPoints(vp));
    }

    public void showEditTextPointAttr(){
        for(EditText et:vEditTextWithPointAttr){
            String name = map.get(et);
            System.out.println("showEditTextPointAttr:"+name);
            if(name.contains("JOYSTICK")){
                et.setText(formatPoint(gameLayout.getJoystick(name).getOriginal()));
            }else if(name.contains("BUTTON")) {
                if(gameLayout.getBtn(name) != null) {
                    et.setText(formatPoints(gameLayout.getBtn(name).getPointList()));
                }
            }
        }
    }

    public String formatPoint(Point point){
        if(point == null){
            return "";
        }else{
            String ret = String.format("(%d,%d)",point.getX(),point.getY());
            System.out.println("formatPoint ret:"+ret);
            return ret;
        }
    }

    public String formatPoints(ArrayList<Point> points){
        if(points == null) return "";
        String ret = "";
        for(Point p:points){
            ret += formatPoint(p)+"/";
        }

        return ret.substring(0,ret.length()-1);
    }

    public void dispToast(String str){
        Toast.makeText(GameLayoutModifyActivity.this,str,Toast.LENGTH_SHORT).show();
    }
}

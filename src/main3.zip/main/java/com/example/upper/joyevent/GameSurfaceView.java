package com.example.upper.joyevent;

/**
 * Created by upper on 18-9-1.
 */

import android.accessibilityservice.AccessibilityService;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Instrumentation;
import android.content.ComponentName;
import android.content.ContextWrapper;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
//import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.hardware.input.InputManager;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.SurfaceView;

import android.content.Context;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.MotionEvent.PointerCoords;
import android.view.MotionEvent.PointerProperties;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

import static java.lang.Math.abs;

public class GameSurfaceView extends SurfaceView implements Callback,Runnable {
    private final static String TAG = "GameSurfaceView";
    private SurfaceHolder mHolder; // 用于控制SurfaceView
    private Context mContext;
    private String mPackageName;

    private Thread t; // 声明一条线程
    private boolean isRunning; // 线程运行的标识，用于控制线程
    private Canvas mCanvas; // 声明一张画布
    private Paint p; // 声明一支画笔
    private int circleX = 0xffff, circleY = 0xffff, circleR = 10; // 圆的坐标和半径
    private int dpadKeyCode = 0xffff;
    private boolean bSelfTestMode = false;

    private Dpad mDpad = new Dpad();
    private GameLayout game = null;
    private static int flagJoystickL = 0;//1:down 2:move 3:up 0:inactive
    private static int flagJoystickR = 0;//1:down 2:move 3:up 0:inactive
    private int originalX_L = 317;
    private int originalY_L = 811;
    private int originalX_R = 1489;
    private int originalY_R = 341;
    private int response_L = 10;
    private int response_R = 10;
    private String type_L;
    private String type_R;
    private int radius_L;//左摇杆半径
    private int radius_R;//右摇杆半径
    public final static int START_X = 306;
    public final static int START_Y = 815;
    public final static int DELTA = 100;
    public final static int MSG_ACTION_DOWN = 0x001;
    public final static int MSG_ACTION_UP = 0x002;
    public final static int MSG_ACTION_MOVE = 0x003;
    public final static int MSG_ACTION_DOWN_JOYSTICKL = 0x011;
    public final static int MSG_ACTION_UP_JOYSTICKL = 0x012;
    public final static int MSG_ACTION_MOVE_JOYSTICKL = 0x013;
    public final static int MSG_ACTION_DOWN_JOYSTICKR = 0x021;
    public final static int MSG_ACTION_UP_JOYSTICKR = 0x022;
    public final static int MSG_ACTION_MOVE_JOYSTICKR = 0x023;

    //两个摇杆同时控制
    public final static int MSG_ACTION_DOWN_JOYSTICK2_1 = 0x031;
    public final static int MSG_ACTION_MOVE_JOYSTICK2_1 = 0x032;
    public final static int MSG_ACTION_UP_JOYSTICK2_1 = 0x033;
    public final static int MSG_ACTION_DOWN_JOYSTICK2_2 = 0x041;
    public final static int MSG_ACTION_MOVE_JOYSTICK2_2 = 0x042;
    public final static int MSG_ACTION_UP_JOYSTICK2_2 = 0x043;

    public final static int MSG_ACTION_SWIPE = 0x010;

    public final Instrumentation mInst = new Instrumentation();
    public final Instrumentation mInst_L = new Instrumentation();
    public final Instrumentation mInst_R = new Instrumentation();
    public final Instrumentation mInst_LR = new Instrumentation();

    PointerProperties[] properties = new PointerProperties[2];
    PointerProperties pp1 = new PointerProperties();
    PointerProperties pp2 = new PointerProperties();
    PointerCoords[] pointerCoords = new PointerCoords[2];

    public boolean bJoystickLFirst = true;
    public boolean bPointer2Mode = false;

    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg){
            super.handleMessage(msg);
            final int x = msg.arg1;
            final int y = msg.arg2;
            Log.d(TAG,String.format("msg:%d,arg1:%d,arg2:%d",msg.what,x,y));

            switch(msg.what){
                case MSG_ACTION_DOWN://Pointer:DOWN
                    //synchronized (mInst) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = System.currentTimeMillis();
                                mInst.sendPointerSync(MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, x, y, 0)); //触摸按下
                            }

                        }).start();
                    //}

                    break;
                case MSG_ACTION_UP://Pointer:UP
                    //synchronized (mInst) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = System.currentTimeMillis();
                                mInst.sendPointerSync(MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_UP, x, y, 0)); //触摸按下
                            }

                        }).start();
                    //}

                    break;
                case MSG_ACTION_MOVE:
                    //synchronized (mInst) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = SystemClock.uptimeMillis()+10;//长按摇杆时，这里不加1000会导致activity响应超时
                                long eventTime = SystemClock.uptimeMillis()+10;
                                mInst.sendPointerSync(MotionEvent.obtain(downTime, eventTime, MotionEvent.ACTION_MOVE, x, y, 0));
                            }

                        }).start();
                    //}

                    break;
                case MSG_ACTION_DOWN_JOYSTICKL:
                    synchronized (mInst_L) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = System.currentTimeMillis();
                                mInst_L.sendPointerSync(MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, x, y, 0)); //触摸按下
                            }

                        }).start();
                    }

                    break;
                case MSG_ACTION_MOVE_JOYSTICKL:
                    synchronized (mInst_L) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = SystemClock.uptimeMillis()+response_L;//长按摇杆时，这里不加1000会导致activity响应超时
                                long eventTime = SystemClock.uptimeMillis()+response_L;
                                mInst_L.sendPointerSync(MotionEvent.obtain(downTime, eventTime, MotionEvent.ACTION_MOVE, x, y, 0));
                            }

                        }).start();
                    }

                    break;
                case MSG_ACTION_UP_JOYSTICKL:
                    synchronized (mInst_L) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = System.currentTimeMillis();
                                mInst_L.sendPointerSync(MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_UP, x, y, 0)); //触摸按下
                            }

                        }).start();
                    }

                    break;
                case MSG_ACTION_DOWN_JOYSTICKR:
                    synchronized (mInst_R) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = System.currentTimeMillis();
                                mInst_R.sendPointerSync(MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, x, y, 0)); //触摸按下
                            }

                        }).start();
                    }

                    break;
                case MSG_ACTION_MOVE_JOYSTICKR:
                    synchronized (mInst_R) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = SystemClock.uptimeMillis()+response_R;//长按摇杆时，这里不加1000会导致activity响应超时
                                long eventTime = SystemClock.uptimeMillis()+response_R;
                                mInst_R.sendPointerSync(MotionEvent.obtain(downTime, eventTime, MotionEvent.ACTION_MOVE, x, y, 0));
                            }

                        }).start();
                    }

                    break;
                case MSG_ACTION_UP_JOYSTICKR:
                    synchronized (mInst_R) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = System.currentTimeMillis();
                                mInst_R.sendPointerSync(MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_UP, x, y, 0)); //触摸按下
                            }

                        }).start();
                    }

                    break;
                case MSG_ACTION_DOWN_JOYSTICK2_1:
                    //synchronized (mInst_LR) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = System.currentTimeMillis();
                                mInst_LR.sendPointerSync(MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_POINTER_1_DOWN, x, y, 0)); //触摸按下
                            }

                        }).start();
                    //}

                    break;
                case MSG_ACTION_MOVE_JOYSTICK2_1:
                    //synchronized (mInst_LR) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = SystemClock.uptimeMillis()+response_R;//长按摇杆时，这里不加1000会导致activity响应超时
                                long eventTime = SystemClock.uptimeMillis()+response_R;
                                mInst_LR.sendPointerSync(MotionEvent.obtain(downTime, eventTime, MotionEvent.ACTION_MOVE, x, y, 0));
                            }

                        }).start();
                    //}

                    break;
                case MSG_ACTION_UP_JOYSTICK2_1:
                    //synchronized (mInst_LR) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = System.currentTimeMillis();
                                mInst_LR.sendPointerSync(MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_POINTER_1_UP, x, y, 0)); //触摸按下
                            }

                        }).start();
                    //}

                    break;
                case MSG_ACTION_DOWN_JOYSTICK2_2:
                    //synchronized (mInst_LR) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = System.currentTimeMillis();
                                mInst_LR.sendPointerSync(MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_POINTER_2_DOWN, x, y, 0)); //触摸按下
                            }

                        }).start();
                    //}

                    break;
                case MSG_ACTION_MOVE_JOYSTICK2_2:
                    //synchronized (mInst_LR) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = SystemClock.uptimeMillis()+response_R;//长按摇杆时，这里不加1000会导致activity响应超时
                                long eventTime = SystemClock.uptimeMillis()+response_R;
                                mInst_LR.sendPointerSync(MotionEvent.obtain(downTime, eventTime, MotionEvent.ACTION_MOVE, x, y, 0));
                            }

                        }).start();
                    //}

                    break;
                case MSG_ACTION_UP_JOYSTICK2_2:
                    //synchronized (mInst_LR) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                long downTime = System.currentTimeMillis();
                                mInst_LR.sendPointerSync(MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_POINTER_2_UP, x, y, 0)); //触摸按下
                            }

                        }).start();
                    //}

                    break;
                case MSG_ACTION_SWIPE://swipe
                    final int type = msg.arg1;
                    Log.d(TAG, String.format("Swipe type:%s", type));

                    //synchronized (mInst) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                float startX = 0, startY = 0, endX = 0, endY = 0;
                                if (type == Dpad.UP) {
                                    startX = START_X;
                                    startY = START_Y;
                                    endX = START_X;
                                    endY = START_Y - DELTA;
                                } else if (type == Dpad.DOWN) {
                                    startX = START_X;
                                    startY = START_Y;
                                    endX = START_X;
                                    endY = START_Y + DELTA;
                                } else if (type == Dpad.LEFT) {
                                    startX = START_X;
                                    startY = START_Y;
                                    endX = START_X - DELTA;
                                    endY = START_Y;
                                } else if (type == Dpad.RIGHT) {
                                    startX = START_X;
                                    startY = START_Y;
                                    endX = START_X + DELTA;
                                    endY = START_Y;
                                } else if (type == Dpad.RIGHT_UP) {
                                    startX = START_X;
                                    startY = START_Y;
                                    endX = START_X + DELTA;
                                    endY = START_Y - DELTA;
                                } else if (type == Dpad.RIGHT_DOWN) {
                                    startX = START_X;
                                    startY = START_Y;
                                    endX = START_X + DELTA;
                                    endY = START_Y + DELTA;
                                } else if (type == Dpad.LEFT_UP) {
                                    startX = START_X;
                                    startY = START_Y;
                                    endX = START_X - DELTA;
                                    endY = START_Y - DELTA;
                                } else if (type == Dpad.LEFT_DOWN) {
                                    startX = START_X;
                                    startY = START_Y;
                                    endX = START_X - DELTA;
                                    endY = START_Y + DELTA;
                                }

                                Log.i(TAG, "Swipe event exec");
                                long downTime = SystemClock.uptimeMillis();
                                long eventTime = SystemClock.uptimeMillis();
                                final int STEP_N = 4;
                                float stepX = (endX - startX) / STEP_N;
                                float stepY = (endY - startY) / STEP_N;
                                mInst.sendPointerSync(MotionEvent.obtain(downTime, eventTime, MotionEvent.ACTION_DOWN, startX, startY, 0)); //触摸按下
                                for (int i = 0; i < STEP_N; i++) {
                                    downTime = SystemClock.uptimeMillis()+10;
                                    eventTime = SystemClock.uptimeMillis()+10;
                                    mInst.sendPointerSync(MotionEvent.obtain(downTime, eventTime, MotionEvent.ACTION_MOVE, startX + i * stepX, startY + i * stepY, 0));
                                }

                                downTime = SystemClock.uptimeMillis();
                                eventTime = SystemClock.uptimeMillis();
                                mInst.sendPointerSync(MotionEvent.obtain(downTime, eventTime, MotionEvent.ACTION_UP, endX, endY, 0)); //触摸抬起
                            }

                        }).start();
                    //}

                    break;
            }

        }
    };

    public GameSurfaceView(Context context,String packageName,boolean bTestMode) {
        super(context);
        Log.i(TAG,"GameSurfaceView constructor enter...");

        mContext = context;
        mPackageName = packageName;
        bSelfTestMode = bTestMode;

        mHolder = getHolder(); // 获得SurfaceHolder对象
        mHolder.addCallback(this); // 为SurfaceView添加状态监听
    }

    public GameSurfaceView(Context context, String packageName) {
        super(context);
        Log.i(TAG,"GameSurfaceView constructor enter...");

        mContext = context;
        mPackageName = packageName;
        bSelfTestMode = false;

        mHolder = getHolder(); // 获得SurfaceHolder对象
        mHolder.addCallback(this); // 为SurfaceView添加状态监听
    }

    /**
     * 当SurfaceView创建的时候，调用此函数
     */
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Log.i(TAG,"surfaceCreated enter...");

        //根据packageName解析gamelayout布局文件
        String xmlpath = GameLayout.DEFAULT_GAMELAYOUT_PATH+mPackageName +".xml";
        File f = new File(xmlpath);
        if(f.exists()){
            Log.i(TAG,"游戏对应xml布局文件存在");
            game = new GameLayout(xmlpath);
            game.parse();

            /*
            try {
                game.create("123");
            } catch (IOException e) {
                e.printStackTrace();
            }*/

            Joystick joystick_L = game.getJoystick("JOYSTICK_L");
            Joystick joystick_R = game.getJoystick("JOYSTICK_R");
            originalX_L = joystick_L.getOriginal().getX();
            originalY_L = joystick_L.getOriginal().getY();
            originalX_R = joystick_R.getOriginal().getX();
            originalY_R = joystick_R.getOriginal().getY();
            radius_L = joystick_L.getRadius();
            radius_R = joystick_R.getRadius();
            type_L = joystick_L.getType();
            type_R = joystick_R.getType();
            response_L = joystick_L.getResponse();
            response_R = joystick_R.getResponse();

            System.out.println("type_L:"+type_L+",type_R:"+type_R);
        }else{
            Log.e(TAG,"游戏对应xml布局文件不存在!!!");
        }

        //setZOrderOnTop(true);
        //setZOrderMediaOverlay(true);
        getHolder().setFormat(PixelFormat.TRANSLUCENT);

        if(bSelfTestMode) {
            p = new Paint(); // 创建一个画笔对象
            p.setColor(Color.WHITE); // 设置画笔的颜色为白色
            p.setTextSize(50);
            //setFocusable(true); // 设置焦点
            //setFocusableInTouchMode(true);
            //requestFocus();
            t = new Thread(this); // 创建一个线程对象
            isRunning = true; // 把线程运行的标识设置成true
            t.start(); // 启动线程
        }
    }

    /**
     * 当SurfaceView的视图发生改变的时候，调用此函数
     */
    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width,
                               int height) {
        Log.i(TAG,"surfaceChanged enter...");
    }

    /**
     * 当SurfaceView销毁的时候，调用此函数
     */
    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.i(TAG,"surfaceDestroyed enter...");
        isRunning = false; // 把线程运行的标识设置成false
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        Log.i(TAG,"on touch event...");
        return false;
    }

    public static final int MOTITONEVENT_BUFFSIZE = 10;
    private boolean initFlag = true;
    private double[] buffer_x = new double[MOTITONEVENT_BUFFSIZE];
    private double[] buffer_y = new double[MOTITONEVENT_BUFFSIZE];
    private double[] buffer_z = new double[MOTITONEVENT_BUFFSIZE];
    private double[] buffer_rz = new double[MOTITONEVENT_BUFFSIZE];
    private int loc = 0;
    private int loc_prev = 0;
    private long recordKeyDownTime = 0;
    private int recordKeyCode = 0;

    public void initMotionEventBuff(){
        for(int i=0;i<MOTITONEVENT_BUFFSIZE;i++){
            buffer_x[i] = 0;
            buffer_y[i] = 0;
            buffer_z[i] = 0;
            buffer_rz[i] = 0;
        }
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent event){
        double x,y,z,rz,rx,ry;
        int ix,iy,iz,irz;
        String keycodelabel = "";
        String tag = "GenericMotionEvent";

        //左右摇杆
        x = event.getAxisValue(MotionEvent.AXIS_X);
        y = event.getAxisValue(MotionEvent.AXIS_Y);
        z = event.getAxisValue(MotionEvent.AXIS_Z);
        rz = event.getAxisValue(MotionEvent.AXIS_RZ);

        rx = event.getAxisValue(MotionEvent.AXIS_RX);
        ry = event.getAxisValue(MotionEvent.AXIS_RY);



        System.out.println(String.format("GenericMotionEvent:\t%f,\t%f,\t%f,\t%f,\t%f,\t%f",(double)Math.round(x*100)/100,(double)Math.round(y*100)/100,(double)Math.round(z*100)/100,(double)Math.round(rz*100)/100,(double)Math.round(rx*100)/100,(double)Math.round(ry*100)/100));
        System.out.println(String.format("max:%f,%f,%f",Math.max(abs(x),abs(y)),Math.max(abs(z),abs(rz)),Math.max(abs(rx),abs(ry))));

        if(KeycodeMap.getMode() == KeycodeMap.MODE_LANMAO){
            //x = event.getAxisValue(MotionEvent.AXIS_RZ);
            //y = event.getAxisValue(MotionEvent.AXIS_Z);
            //z = event.getAxisValue(MotionEvent.AXIS_Y);
            //rz = event.getAxisValue(MotionEvent.AXIS_X);
        }

        if(initFlag){
            initMotionEventBuff();
            initFlag = false;
        }

        buffer_x[loc] = x;
        buffer_y[loc] = y;
        buffer_z[loc] = z;
        buffer_rz[loc] = rz;

        analysis_L(buffer_x,buffer_y);
        analysis_R(buffer_z,buffer_rz);

        /*
        //++++方向键（仅调试betop手柄）++++
        if(Dpad.isDpadDevice(event)){
            int press = mDpad.getDirectionPressed(event);
            int action = mDpad.getAction(event);
            if(press != -1) {
                Log.d(tag, "DPAD Press:" + press + ",action:" + action);
                switch (press) {
                    case Dpad.UP:
                        keycodelabel = "BUTTON_UP";
                        doActionWithKeyCodeLabel(keycodelabel, action);
                        break;
                    case Dpad.DOWN:
                        keycodelabel = "BUTTON_DOWN";
                        doActionWithKeyCodeLabel(keycodelabel, action);
                        break;
                    case Dpad.LEFT:
                        keycodelabel = "BUTTON_LEFT";
                        doActionWithKeyCodeLabel(keycodelabel, action);
                        break;
                    case Dpad.RIGHT:
                        keycodelabel = "BUTTON_RIGHT";
                        doActionWithKeyCodeLabel(keycodelabel, action);
                        break;
                }
            }
        }
        //----方向键（仅调试betop手柄）----
        */

        ix = (int)(radius_L*x);iy=(int)(radius_L*y);
        iz = (int)(radius_R*z);irz=(int)(radius_R*rz);

        int joystickType = mDpad.getJoystickType(event);
        if (joystickType == Dpad.JOYSTICK_L) {
            System.out.println("检测到左摇杆操作");
            if(type_L.equals(GameLayout.TYPE_JOYSTICK_STANDARD)) {
                if (flagJoystickL == 0) {
                    Log.i(TAG, "L:DOWN");
                    flagJoystickL = 1;
                    sendPointerMessage(GameLayout.JOYSTICK_L,originalX_L + ix, originalY_L + iy, MotionEvent.ACTION_DOWN);
                } else if (flagJoystickL == 1 || flagJoystickL == 2) {
                    Log.i(TAG, "L:MOVING");
                    flagJoystickL = 2;
                    sendMoveMessage(GameLayout.JOYSTICK_L, originalX_L + ix, originalY_L + iy);
                }
            }else if(type_L.equals(GameLayout.TYPE_JOYSTICK_DIRECTION)){
                if (flagJoystickL == 0) {
                    Log.i(TAG, "L:DOWN");
                    flagJoystickL = 1;
                    sendPointerMessage(GameLayout.JOYSTICK_L,originalX_L + ix, originalY_L + iy, MotionEvent.ACTION_DOWN);
                } else if (flagJoystickL == 1 || flagJoystickL == 2) {
                    Log.i(TAG, "L:MOVING");
                    if(turnback_L()) {
                        System.out.println("turn back L...");
                        flagJoystickL = 0;
                        sendPointerMessage(GameLayout.JOYSTICK_L, originalX_L + ix, originalY_L + iy, MotionEvent.ACTION_UP);
                    }else {
                        flagJoystickL = 2;
                        sendMoveMessage(GameLayout.JOYSTICK_L, originalX_L + ix, originalY_L + iy);
                    }
                }
            }

            //同时控制双摇杆时，需要判断另一个摇杆状态
            if (flagJoystickR == 2) {
                Log.i(tag, "R:UP");
                flagJoystickR = 0;
                sendPointerMessage(GameLayout.JOYSTICK_R, originalX_R + iz, originalY_R + irz, MotionEvent.ACTION_UP);
            }
        } else if (joystickType == Dpad.JOYSTICK_R) {
            System.out.println("检测到右摇杆操作");
            if(type_R.equals(GameLayout.TYPE_JOYSTICK_STANDARD)) {
                if (flagJoystickR == 0) {
                    Log.i(tag, "R:DOWN");
                    flagJoystickR = 1;
                    sendPointerMessage(GameLayout.JOYSTICK_R, originalX_R + iz, originalY_R + irz, MotionEvent.ACTION_DOWN);
                } else if (flagJoystickR == 1 || flagJoystickR == 2) {
                    Log.i(tag, "R:MOVING");
                    flagJoystickR = 2;
                    sendMoveMessage(GameLayout.JOYSTICK_R, originalX_R + iz, originalY_R + irz);
                }
            }else if(type_R.equals(GameLayout.TYPE_JOYSTICK_DIRECTION)){
                if (flagJoystickR == 0) {
                    Log.i(tag, "R:DOWN");
                    flagJoystickR = 1;
                    sendPointerMessage(GameLayout.JOYSTICK_R, originalX_R + iz, originalY_R + irz, MotionEvent.ACTION_DOWN);
                } else if (flagJoystickR == 1 || flagJoystickR == 2) {
                    Log.i(tag, "R:MOVING");
                    if(!turnback_R()){
                        flagJoystickR = 2;
                        sendMoveMessage(GameLayout.JOYSTICK_R, originalX_R + iz, originalY_R + irz);
                    }else{
                        flagJoystickR = 0;
                        sendPointerMessage(GameLayout.JOYSTICK_R, originalX_R + iz, originalY_R + irz, MotionEvent.ACTION_UP);
                    }
                }
            }


            //同时控制双摇杆时，需要判断另一个摇杆状态
            if (flagJoystickL == 2) {
                Log.i(tag, "L:UP");
                flagJoystickL = 0;
                sendPointerMessage(GameLayout.JOYSTICK_L, originalX_L + ix, originalY_L + iy, MotionEvent.ACTION_UP);
            }
        } else if(joystickType == Dpad.JOYSTICK_L+Dpad.JOYSTICK_R){
            System.out.println("检测到左右摇杆同时操作");
            /*if(type_L.equals(GameLayout.TYPE_JOYSTICK_STANDARD)) {
                if (flagJoystickL == 0) {
                    Log.i(TAG, "L:DOWN");
                    flagJoystickL = 1;
                    sendPointerMessage(GameLayout.JOYSTICK_L,originalX_L + ix, originalY_L + iy, MotionEvent.ACTION_DOWN);
                } else if (flagJoystickL == 1 || flagJoystickL == 2) {
                    Log.i(TAG, "L:MOVING");
                    flagJoystickL = 2;
                    sendMoveMessage(GameLayout.JOYSTICK_L,originalX_L + ix, originalY_L + iy);
                }
            }

            if(type_R.equals(GameLayout.TYPE_JOYSTICK_STANDARD)) {
                if (flagJoystickR == 0) {
                    Log.i(tag, "R:DOWN");
                    flagJoystickR = 1;
                    sendPointerMessage(GameLayout.JOYSTICK_R, originalX_R + iz, originalY_R + irz, MotionEvent.ACTION_DOWN);
                } else if (flagJoystickR == 1 || flagJoystickR == 2) {
                    Log.i(tag, "R:MOVING");
                    flagJoystickR = 2;
                    sendMoveMessage(GameLayout.JOYSTICK_R,originalX_R + iz, originalY_R + irz);
                }
            }*/

            bPointer2Mode = true;
            if (flagJoystickL == 0 && flagJoystickR != 0) {//先右摇杆，后左摇杆
                System.out.println("L:DOWN after R");
                bJoystickLFirst = false;
                flagJoystickL = 1;
                sendPointerMessage(GameLayout.JOYSTICK_L+GameLayout.JOYSTICK_R+0x10,originalX_L + ix, originalY_L + iy, MotionEvent.ACTION_DOWN);
            } else if(flagJoystickR == 0 && flagJoystickL != 0){//先左摇杆，后右摇杆
                System.out.println( "R:DOWN after L");
                bJoystickLFirst = true;
                flagJoystickR = 1;
                sendPointerMessage(GameLayout.JOYSTICK_L+GameLayout.JOYSTICK_R+0x10,originalX_R + iz, originalY_L + irz, MotionEvent.ACTION_DOWN);
            } else if(flagJoystickR == 0 && flagJoystickL == 0){//同时控制摇杆
                System.out.println("Both L and R");
                //默认认为左摇杆为第一
                bJoystickLFirst = true;
                flagJoystickL = 1;
                sendPointerMessage(GameLayout.JOYSTICK_L+GameLayout.JOYSTICK_R,originalX_L + ix, originalY_L + iy, MotionEvent.ACTION_DOWN);
                //默认认为右摇杆为第二
                flagJoystickR = 1;
                sendPointerMessage(GameLayout.JOYSTICK_L+GameLayout.JOYSTICK_R+0x10,originalX_R + iz, originalY_L + irz, MotionEvent.ACTION_DOWN);
            } else if ((flagJoystickL != 0 && flagJoystickR != 0)) {
                System.out.println( "L:MOVING,R:MOVING");
                flagJoystickL = 2;
                flagJoystickR = 2;
                sendMoveMessage(GameLayout.JOYSTICK_L+GameLayout.JOYSTICK_R+0x10,originalX_L + ix, originalY_L + iy);
                sendMoveMessage(GameLayout.JOYSTICK_L+GameLayout.JOYSTICK_R+0x10,originalX_R + iz, originalY_R + irz);
            }

        } else {
            System.out.println("未检测到摇杆操作");
            if(type_L.equals(GameLayout.TYPE_JOYSTICK_STANDARD)) {
                if (flagJoystickL == 2) {
                    Log.i(tag, "L:UP");
                    flagJoystickL = 0;
                    sendPointerMessage(GameLayout.JOYSTICK_L, originalX_L + ix, originalY_L + iy, MotionEvent.ACTION_UP);
                }
            }

            if(type_R.equals(GameLayout.TYPE_JOYSTICK_STANDARD)) {
                if (flagJoystickR == 2) {
                    Log.i(tag, "R:UP");
                    flagJoystickR = 0;
                    sendPointerMessage(GameLayout.JOYSTICK_R, originalX_R + iz, originalY_R + irz, MotionEvent.ACTION_UP);
                }
            }
        }

        loc_prev = loc;
        loc = (loc+1)%MOTITONEVENT_BUFFSIZE;
        return true;
    }

    public boolean analysis_L(double[] buff_x,double[] buff_y){
        return true;
    }

    public boolean analysis_R(double[] buff_z,double[] buff_rz){
        return true;
    }

    public boolean turnback_L(){
        double curr_x = buffer_x[loc];
        double curr_y = buffer_y[loc];
        double prev_x = buffer_x[loc_prev];
        double prev_y = buffer_y[loc_prev];

        double curr_powsum = (Math.pow(curr_x,2)+Math.pow(curr_y,2));
        double prev_powsum = (Math.pow(prev_x,2)+Math.pow(prev_y,2));
        double thre_powsum = (Math.pow(Dpad.validJoystickThresholdX,2)+Math.pow(Dpad.validJoystickThresholdY,2));
        if(curr_powsum > prev_powsum && curr_powsum > thre_powsum){
            return false;
        }else{
            return true;
        }
    }

    public boolean turnback_R(){
        double curr_z = buffer_z[loc];
        double curr_rz = buffer_rz[loc];
        double prev_z = buffer_z[loc_prev];
        double prev_rz = buffer_rz[loc_prev];

        double curr_powsum = (Math.pow(curr_z,2)+Math.pow(curr_rz,2));
        double prev_powsum = (Math.pow(prev_z,2)+Math.pow(prev_rz,2));
        double thre_powsum = (Math.pow(Dpad.validJoystickThresholdX,2)+Math.pow(Dpad.validJoystickThresholdY,2));
        if(curr_powsum > prev_powsum && curr_powsum > thre_powsum){
            return false;
        }else{
            return true;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event){
        Log.i(TAG,"dispatchKeyEvent enter...");
        if(event.getKeyCode() == KeyEvent.KEYCODE_BACK){
            //return false;
        }

        Log.i(TAG,"dispatchKeyEvent done.");
        return super.dispatchKeyEvent(event);
    }

    /**
     * 当用户按键时调用
     */
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event){
        Log.i(TAG, "onKeyUp:"+keyCode);
        dpadKeyCode = 0xffff;

        if(keyCode == KeyEvent.KEYCODE_BACK){
            return true;
        }

        int action = event.getAction();
        String keycodelabel = KeycodeMap.getKey(keyCode);
        Log.i(TAG, String.format("keycode:%d,keycodelabel:%s", keyCode, keycodelabel));
        doActionWithKeyCodeLabel(keycodelabel,MotionEvent.ACTION_UP);

        return true;
    }

    //根据按键名执行相应操作（xml文件定义）
    public boolean doActionWithKeyCodeLabel(String keycodelabel,int action){
        if(game != null){
            Btn btn = game.getBtnsMap().get(keycodelabel);
            if(btn != null){
                if (btn.getAction().equals(GameLayout.ACTION_CLICK)) {
                    if(action == MotionEvent.ACTION_DOWN) {
                        if (btn.getType().equals(GameLayout.TYPE_MULTI)) {//该按钮为multi多点复用，需要处理index
                            Log.i(TAG, "当前index：" + btn.getPointIndex());
                            btn.increasePointIndex();
                            Log.i(TAG, "下个index：" + btn.getPointIndex());
                        }
                    }
                    Point point = btn.getPoint();
                    if(point == null) return false;
                    Log.i(TAG,"x:"+point.getX()+",:"+point.getY());
                    sendPointerMessage(point.getX(), point.getY(), action);
                } else if (btn.getAction().equals(GameLayout.ACTION_SWIPE)) {

                }

                return true;
            }else{
                Log.e(TAG,"Btn NOT defined");
                return false;
            }
        }else{
            Log.i(TAG,"[KeyUp]game is null");

            return false;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Log.d(TAG,"onKeyDown:"+keyCode);
        dpadKeyCode = keyCode;

        long currTime = System.currentTimeMillis();
        if(currTime - recordKeyDownTime > 50){//50ms内判断是否同时按下多个键
            recordKeyDownTime = currTime;
            recordKeyCode = keyCode;
        }else{
            if(recordKeyCode != keyCode) {
                System.out.println("检测连续按不同键："+recordKeyCode+","+keyCode);
                //按组合键处理

            }else{
                System.out.println("检测连续按相同键");
                //不处理
            }
        }

        if(keyCode == KeyEvent.KEYCODE_BACK){
            return true;
        }

        int action = event.getAction();
        String keycodelabel = KeycodeMap.getKey(keyCode);
        doActionWithKeyCodeLabel(keycodelabel,MotionEvent.ACTION_DOWN);

        return true;
    }

    @Override
    public void run() {

        while (isRunning == true) {
            Draw(); // 调用自定义画画方法
            try {
                Thread.sleep(10); // 让线程休息50毫秒
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void Draw() {
        mCanvas = mHolder.lockCanvas(); // 获得画布对象，开始对画布画画
        if(mCanvas != null) {
            //mCanvas.drawRGB(0, 0x80, 0); // 把画布填充为绿色
            if (circleX != 0xffff && circleY != 0xffff) {
                mCanvas.drawCircle(circleX, circleY, circleR, p); // 画一个圆
            }

            if (dpadKeyCode != 0xffff) {
                mCanvas.drawText("" + dpadKeyCode, 500, 500, p);
            }

            mHolder.unlockCanvasAndPost(mCanvas); // 完成画画，把画布显示在屏幕上
        }
    }

    public final boolean sendSwipeMessage(int type){
        Message msg = Message.obtain();
        msg.what = MSG_ACTION_SWIPE;
        msg.arg1 = type;

        return mHandler.sendMessage(msg);
    }

    public final boolean sendSwipeMessage(int type,int subtype){
        Message msg = Message.obtain();
        msg.what = MSG_ACTION_SWIPE;
        msg.arg1 = type;
        msg.arg2 = subtype;

        return mHandler.sendMessage(msg);
    }

    public final boolean sendMoveMessage(int x,int y){
        Log.i(TAG,"send move message");
        Message msg = Message.obtain();
        msg.what = MSG_ACTION_MOVE;
        msg.arg1 = x;
        msg.arg2 = y;

        if(bSelfTestMode){
            circleX = x;
            circleY = y;
        }

        return mHandler.sendMessage(msg);
    }

    public final boolean sendMoveMessage(int joystickType,int x,int y){
        Log.i(TAG,"send move message");
        Message msg = Message.obtain();
        msg.what = joystickType+MSG_ACTION_MOVE;
        msg.arg1 = x;
        msg.arg2 = y;

        if(bSelfTestMode){
            circleX = x;
            circleY = y;
        }

        return mHandler.sendMessage(msg);
    }

    //joystickType取值GameLayout.JOYSTICK_L和GameLayout.JOYSTICK_R
    public final boolean sendPointerMessage(int joystickType,int x,int y,int action){
        Message msg = Message.obtain();
        if(action == MotionEvent.ACTION_DOWN){
            msg.what = joystickType + MSG_ACTION_DOWN;
            if(bSelfTestMode){
                circleX = x;
                circleY = y;
            }

        }else if(action == MotionEvent.ACTION_UP){
            msg.what = joystickType + MSG_ACTION_UP;
            if(bSelfTestMode){
                circleX = 0xffff;
                circleY = 0xffff;
            }
        }

        msg.arg1 = x;
        msg.arg2 = y;

        return mHandler.sendMessage(msg);
    }

    public final boolean sendPointerMessage(int x,int y,int action){
        Message msg = Message.obtain();
        if(action == MotionEvent.ACTION_DOWN){
            msg.what = MSG_ACTION_DOWN;
            if(bSelfTestMode){
                circleX = x;
                circleY = y;
            }

        }else if(action == MotionEvent.ACTION_UP){
            msg.what = MSG_ACTION_UP;
            if(bSelfTestMode){
                circleX = 0xffff;
                circleY = 0xffff;
            }
        }

        msg.arg1 = x;
        msg.arg2 = y;

        return mHandler.sendMessage(msg);
    }
}
